<?php 
	include_once "controller/" . ucfirst($c) . "Controller.php";
	include_once "service/ImageService.php";
	include_once "service/MailSenderService.php";
	include_once "service/ACLService.php";
	include_once "service/ParamToAclActionService.php";
 ?>